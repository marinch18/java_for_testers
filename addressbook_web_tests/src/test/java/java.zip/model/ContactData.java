package model;

public record ContactData(String id,
                        String firstName,
                        String middleName,
                        String lastName,
                        String address,
                        String home,
                        String mobile,
                        String work,
                        String phone2,
                        String email,
                        String email2,
                        String email3,
                        String photo) {


    public  ContactData() {
        this("", "", "", "", "", "", "", "", "", "", "", "", "");
    }

    public ContactData withId(String id) {
        return new ContactData(id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withFirstName(String firstName) {
        return new ContactData(this.id, firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withMiddleName(String middleName) {
        return new ContactData(this.id, this.firstName, middleName, this.lastName, this.address, this.home, this.mobile,
                this.work,  this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withLastName(String lastName) {
        return new ContactData(this.id, this.firstName, this.middleName, lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withAddress(String address) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, address, this.home, this.mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withHome(String home) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, home, this.mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withMobile(String mobile) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, mobile,
                this.work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withWork(String work) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                work, this.phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withSecondPhone(String phone2) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, phone2, this.email, this.email2, this.email3, this.photo);
    }

    public ContactData withEmail(String email) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, email, this.email2, this.email3, this.photo);
    }

    public ContactData withEmail2(String email2) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, this.email, email2, this.email3, this.photo);
    }

    public ContactData withEmail3(String email3) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                this.work, this.phone2, this.email, this.email2, email3, this.photo);
    }

    public ContactData withPhoto(String photo) {
        return new ContactData(this.id, this.firstName, this.middleName, this.lastName, this.address, this.home, this.mobile,
                    this.work, this.phone2, this.email, this.email2, this.email3, photo);
    }

}
